

<?php $__env->startSection('content'); ?>
    <div class="p-4 mx-auto max-w-(--breakpoint-2xl) md:p-6">
        <!-- Breadcrumb Start -->
        <?php if (isset($component)) { $__componentOriginal449bf9b97ed15487a2dd22def0878ac7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal449bf9b97ed15487a2dd22def0878ac7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.breadcrumb.type-1','data' => ['breadcrumbs' => [['label' => 'Beranda', 'url' => route('dashboard')], ['label' => 'Partners', 'url' => null]]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('breadcrumb.type-1'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['breadcrumbs' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([['label' => 'Beranda', 'url' => route('dashboard')], ['label' => 'Partners', 'url' => null]])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal449bf9b97ed15487a2dd22def0878ac7)): ?>
<?php $attributes = $__attributesOriginal449bf9b97ed15487a2dd22def0878ac7; ?>
<?php unset($__attributesOriginal449bf9b97ed15487a2dd22def0878ac7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal449bf9b97ed15487a2dd22def0878ac7)): ?>
<?php $component = $__componentOriginal449bf9b97ed15487a2dd22def0878ac7; ?>
<?php unset($__componentOriginal449bf9b97ed15487a2dd22def0878ac7); ?>
<?php endif; ?>
        <!-- Breadcrumb End -->

        <!-- Alert -->
        <?php if (isset($component)) { $__componentOriginal1903f97dee5fcea293eac5373b200b35 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1903f97dee5fcea293eac5373b200b35 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert.alert-1','data' => ['success' => session('success'),'error' => session('error')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('alert.alert-1'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['success' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(session('success')),'error' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(session('error'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1903f97dee5fcea293eac5373b200b35)): ?>
<?php $attributes = $__attributesOriginal1903f97dee5fcea293eac5373b200b35; ?>
<?php unset($__attributesOriginal1903f97dee5fcea293eac5373b200b35); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1903f97dee5fcea293eac5373b200b35)): ?>
<?php $component = $__componentOriginal1903f97dee5fcea293eac5373b200b35; ?>
<?php unset($__componentOriginal1903f97dee5fcea293eac5373b200b35); ?>
<?php endif; ?>

        <div class="space-y-5 sm:space-y-6">
            <div class="rounded-2xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-white/[0.03]">
                <div class="flex items-center justify-between px-5 py-4 sm:px-6 sm:py-5">
                    <h3 class="text-base font-medium text-gray-800 dark:text-white/90">
                        Partner List
                    </h3>
                    <div class="flex justify-end space-x-2">
                        <a href="<?php echo e(route('partner.create')); ?>"
                            class="btn-primary bg-blue-500 text-white text-sm px-4 py-2 rounded-md hover:bg-blue-600 dark:hover:bg-blue-400 transition">
                            Tambah Partner
                        </a>
                    </div>
                </div>

                <div class="border-t border-gray-100 dark:border-gray-800">
                    <!-- ====== Table Six Start -->
                    <?php if (isset($component)) { $__componentOriginal5b54287f7f6b8b2c0ec3a441b4764375 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5b54287f7f6b8b2c0ec3a441b4764375 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.tables.table-partners','data' => ['headers' => ['ID', 'Nama Partner', 'Email', 'Tanggal Buat', 'Action'],'rows' => $partners,'btnAction' => [
                            [
                                'label' => 'Ubah',
                                'route' => 'partner.edit',
                                'method' => null,
                            ],
                            [
                                'label' => 'Hapus',
                                'route' => 'partner.destroy',
                                'method' => 'delete',
                            ],
                        ]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('tables.table-partners'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['headers' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(['ID', 'Nama Partner', 'Email', 'Tanggal Buat', 'Action']),'rows' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($partners),'btnAction' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([
                            [
                                'label' => 'Ubah',
                                'route' => 'partner.edit',
                                'method' => null,
                            ],
                            [
                                'label' => 'Hapus',
                                'route' => 'partner.destroy',
                                'method' => 'delete',
                            ],
                        ])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5b54287f7f6b8b2c0ec3a441b4764375)): ?>
<?php $attributes = $__attributesOriginal5b54287f7f6b8b2c0ec3a441b4764375; ?>
<?php unset($__attributesOriginal5b54287f7f6b8b2c0ec3a441b4764375); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5b54287f7f6b8b2c0ec3a441b4764375)): ?>
<?php $component = $__componentOriginal5b54287f7f6b8b2c0ec3a441b4764375; ?>
<?php unset($__componentOriginal5b54287f7f6b8b2c0ec3a441b4764375); ?>
<?php endif; ?>
                    <!-- ====== Table Six End -->
                </div>
            </div>
        </div>
    </div>

    <?php if (isset($component)) { $__componentOriginalbdc31d7c11973739af12d66580af931c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbdc31d7c11973739af12d66580af931c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.js.flowbite-datatable','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('js.flowbite-datatable'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbdc31d7c11973739af12d66580af931c)): ?>
<?php $attributes = $__attributesOriginalbdc31d7c11973739af12d66580af931c; ?>
<?php unset($__attributesOriginalbdc31d7c11973739af12d66580af931c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbdc31d7c11973739af12d66580af931c)): ?>
<?php $component = $__componentOriginalbdc31d7c11973739af12d66580af931c; ?>
<?php unset($__componentOriginalbdc31d7c11973739af12d66580af931c); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard-app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\PROJECT\management-hotel-dieng\resources\views/partner/index.blade.php ENDPATH**/ ?>