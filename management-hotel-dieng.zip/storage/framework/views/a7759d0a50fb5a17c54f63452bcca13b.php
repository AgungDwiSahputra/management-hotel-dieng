<div class="grid grid-cols-1 gap-4 sm:grid-cols-2 md:gap-6">
    <!-- Total Pendapatan Pemesanan per-Bulan -->
    <?php if (isset($component)) { $__componentOriginalee9c896fc834a1ad283455c1e4240144 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalee9c896fc834a1ad283455c1e4240144 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.box.metric-item','data' => ['title' => 'Total Pemesanan (per-Bulan)','count' => ''.e('Rp. ' . number_format($countTotalReservationPerMonth[date('m')] ?? 0, 0, ',', '.')).'','showPercent' => 'true','percent' => ''.e($percentTotalReservationPerMonth ?? 0).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('box.metric-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Total Pemesanan (per-Bulan)','count' => ''.e('Rp. ' . number_format($countTotalReservationPerMonth[date('m')] ?? 0, 0, ',', '.')).'','showPercent' => 'true','percent' => ''.e($percentTotalReservationPerMonth ?? 0).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalee9c896fc834a1ad283455c1e4240144)): ?>
<?php $attributes = $__attributesOriginalee9c896fc834a1ad283455c1e4240144; ?>
<?php unset($__attributesOriginalee9c896fc834a1ad283455c1e4240144); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalee9c896fc834a1ad283455c1e4240144)): ?>
<?php $component = $__componentOriginalee9c896fc834a1ad283455c1e4240144; ?>
<?php unset($__componentOriginalee9c896fc834a1ad283455c1e4240144); ?>
<?php endif; ?>

    <!-- Total Pendapatan Pemesanan Semua -->
    <?php if (isset($component)) { $__componentOriginalee9c896fc834a1ad283455c1e4240144 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalee9c896fc834a1ad283455c1e4240144 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.box.metric-item','data' => ['title' => 'Total Pemesanan (Semua)','count' => ''.e('Rp. ' . number_format($countTotalReservation ?? 0, 0, ',', '.')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('box.metric-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Total Pemesanan (Semua)','count' => ''.e('Rp. ' . number_format($countTotalReservation ?? 0, 0, ',', '.')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalee9c896fc834a1ad283455c1e4240144)): ?>
<?php $attributes = $__attributesOriginalee9c896fc834a1ad283455c1e4240144; ?>
<?php unset($__attributesOriginalee9c896fc834a1ad283455c1e4240144); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalee9c896fc834a1ad283455c1e4240144)): ?>
<?php $component = $__componentOriginalee9c896fc834a1ad283455c1e4240144; ?>
<?php unset($__componentOriginalee9c896fc834a1ad283455c1e4240144); ?>
<?php endif; ?>

    <!-- Total Produk -->
    <?php if (isset($component)) { $__componentOriginalee9c896fc834a1ad283455c1e4240144 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalee9c896fc834a1ad283455c1e4240144 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.box.metric-item','data' => ['title' => 'Total Produk','count' => ''.e($countProducts ?? 0).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('box.metric-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Total Produk','count' => ''.e($countProducts ?? 0).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalee9c896fc834a1ad283455c1e4240144)): ?>
<?php $attributes = $__attributesOriginalee9c896fc834a1ad283455c1e4240144; ?>
<?php unset($__attributesOriginalee9c896fc834a1ad283455c1e4240144); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalee9c896fc834a1ad283455c1e4240144)): ?>
<?php $component = $__componentOriginalee9c896fc834a1ad283455c1e4240144; ?>
<?php unset($__componentOriginalee9c896fc834a1ad283455c1e4240144); ?>
<?php endif; ?>

    <!-- Total Pemesanan -->
    <?php if (isset($component)) { $__componentOriginalee9c896fc834a1ad283455c1e4240144 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalee9c896fc834a1ad283455c1e4240144 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.box.metric-item','data' => ['title' => 'Total Pemesanan','count' => ''.e($countReservations ?? 0).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('box.metric-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Total Pemesanan','count' => ''.e($countReservations ?? 0).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalee9c896fc834a1ad283455c1e4240144)): ?>
<?php $attributes = $__attributesOriginalee9c896fc834a1ad283455c1e4240144; ?>
<?php unset($__attributesOriginalee9c896fc834a1ad283455c1e4240144); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalee9c896fc834a1ad283455c1e4240144)): ?>
<?php $component = $__componentOriginalee9c896fc834a1ad283455c1e4240144; ?>
<?php unset($__componentOriginalee9c896fc834a1ad283455c1e4240144); ?>
<?php endif; ?>
</div>

<?php /**PATH D:\PROJECT\management-hotel-dieng\resources\views/partials/metric-group/metric-group-01.blade.php ENDPATH**/ ?>