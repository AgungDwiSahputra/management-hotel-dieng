

<?php $__env->startSection('content'); ?>
    <div class="p-4 mx-auto max-w-(--breakpoint-2xl) md:p-6">
        <div class="grid grid-cols-12 gap-4 md:gap-6">
            <div class="col-span-12 space-y-6">
                <!-- Metric Group One -->
                <?php echo $__env->make('partials.metric-group.metric-group-01', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <!-- Metric Group One -->

                <!-- ====== Table One Start -->
                
                <!-- ====== Table One End -->
            </div>
        </div>
    </div>

    <?php if (isset($component)) { $__componentOriginalbdc31d7c11973739af12d66580af931c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbdc31d7c11973739af12d66580af931c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.js.flowbite-datatable','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('js.flowbite-datatable'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbdc31d7c11973739af12d66580af931c)): ?>
<?php $attributes = $__attributesOriginalbdc31d7c11973739af12d66580af931c; ?>
<?php unset($__attributesOriginalbdc31d7c11973739af12d66580af931c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbdc31d7c11973739af12d66580af931c)): ?>
<?php $component = $__componentOriginalbdc31d7c11973739af12d66580af931c; ?>
<?php unset($__componentOriginalbdc31d7c11973739af12d66580af931c); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard-app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\PROJECT\management-hotel-dieng\resources\views/index.blade.php ENDPATH**/ ?>