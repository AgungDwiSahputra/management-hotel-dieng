

<?php $__env->startSection('content'); ?>
    <div class="p-4 mx-auto max-w-(--breakpoint-2xl) md:p-6">
        <!-- Breadcrumb Start -->
        <?php if (isset($component)) { $__componentOriginal449bf9b97ed15487a2dd22def0878ac7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal449bf9b97ed15487a2dd22def0878ac7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.breadcrumb.type-1','data' => ['breadcrumbs' => [
            ['label' => 'Beranda', 'url' => route('dashboard')],
            ['label' => 'Produk', 'url' => route('product.index')],
            ['label' => 'Detail Produk', 'url' => null],
        ]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('breadcrumb.type-1'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['breadcrumbs' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([
            ['label' => 'Beranda', 'url' => route('dashboard')],
            ['label' => 'Produk', 'url' => route('product.index')],
            ['label' => 'Detail Produk', 'url' => null],
        ])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal449bf9b97ed15487a2dd22def0878ac7)): ?>
<?php $attributes = $__attributesOriginal449bf9b97ed15487a2dd22def0878ac7; ?>
<?php unset($__attributesOriginal449bf9b97ed15487a2dd22def0878ac7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal449bf9b97ed15487a2dd22def0878ac7)): ?>
<?php $component = $__componentOriginal449bf9b97ed15487a2dd22def0878ac7; ?>
<?php unset($__componentOriginal449bf9b97ed15487a2dd22def0878ac7); ?>
<?php endif; ?>
        <!-- Breadcrumb End -->

        <div class="space-y-5 sm:space-y-6">
            <div class="rounded-2xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-white/[0.03]">
                <div class="flex items-center justify-between px-5 py-4 sm:px-6 sm:py-5">
                    <h3 class="text-base font-medium text-gray-800 dark:text-white/90">
                        Detail Produk
                    </h3>
                </div>
                <div class="border-t border-gray-100 dark:border-gray-800">
                    <?php if (isset($component)) { $__componentOriginal473a9d24b7808aa82216a3d42c3cd30e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal473a9d24b7808aa82216a3d42c3cd30e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.products.form','data' => ['action' => route('product.update', $product['id']),'method' => 'put','inputs' => [
                            'name' => ['label' => 'Nama Produk', 'type' => 'text', 'value' => old('name', $product['name'])],
                            'unit' => ['label' => 'Jumlah Unit', 'type' => 'number', 'value' => old('unit', $product['unit'])],
                            'harga_weekday' => ['label' => 'Harga Weekday', 'type' => 'number', 'value' => old('harga_weekday', $product['harga_weekday'])],
                            'harga_weekend' => ['label' => 'Harga Weekend', 'type' => 'number', 'value' => old('harga_weekend', $product['harga_weekend'])],
                        ],'btnCancel' => ['label' => 'Batal'],'btnSubmit' => ['label' => 'Ubah']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form.products.form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['action' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('product.update', $product['id'])),'method' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('put'),'inputs' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([
                            'name' => ['label' => 'Nama Produk', 'type' => 'text', 'value' => old('name', $product['name'])],
                            'unit' => ['label' => 'Jumlah Unit', 'type' => 'number', 'value' => old('unit', $product['unit'])],
                            'harga_weekday' => ['label' => 'Harga Weekday', 'type' => 'number', 'value' => old('harga_weekday', $product['harga_weekday'])],
                            'harga_weekend' => ['label' => 'Harga Weekend', 'type' => 'number', 'value' => old('harga_weekend', $product['harga_weekend'])],
                        ]),'btn-cancel' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(['label' => 'Batal']),'btn-submit' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(['label' => 'Ubah'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal473a9d24b7808aa82216a3d42c3cd30e)): ?>
<?php $attributes = $__attributesOriginal473a9d24b7808aa82216a3d42c3cd30e; ?>
<?php unset($__attributesOriginal473a9d24b7808aa82216a3d42c3cd30e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal473a9d24b7808aa82216a3d42c3cd30e)): ?>
<?php $component = $__componentOriginal473a9d24b7808aa82216a3d42c3cd30e; ?>
<?php unset($__componentOriginal473a9d24b7808aa82216a3d42c3cd30e); ?>
<?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard-app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\PROJECT\management-hotel-dieng\resources\views/product/show.blade.php ENDPATH**/ ?>