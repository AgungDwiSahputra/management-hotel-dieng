

<?php $__env->startSection('content'); ?>
    <div class="p-4 mx-auto max-w-(--breakpoint-2xl) md:p-6">
        <!-- Breadcrumb Start -->
        <?php if (isset($component)) { $__componentOriginal449bf9b97ed15487a2dd22def0878ac7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal449bf9b97ed15487a2dd22def0878ac7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.breadcrumb.type-1','data' => ['breadcrumbs' => [
            ['label' => 'Beranda', 'url' => route('dashboard')],
            ['label' => 'Partner', 'url' => route('partner.index')],
            ['label' => 'Buat Partner', 'url' => null],
        ]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('breadcrumb.type-1'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['breadcrumbs' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([
            ['label' => 'Beranda', 'url' => route('dashboard')],
            ['label' => 'Partner', 'url' => route('partner.index')],
            ['label' => 'Buat Partner', 'url' => null],
        ])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal449bf9b97ed15487a2dd22def0878ac7)): ?>
<?php $attributes = $__attributesOriginal449bf9b97ed15487a2dd22def0878ac7; ?>
<?php unset($__attributesOriginal449bf9b97ed15487a2dd22def0878ac7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal449bf9b97ed15487a2dd22def0878ac7)): ?>
<?php $component = $__componentOriginal449bf9b97ed15487a2dd22def0878ac7; ?>
<?php unset($__componentOriginal449bf9b97ed15487a2dd22def0878ac7); ?>
<?php endif; ?>
        <!-- Breadcrumb End -->

        <div class="space-y-5 sm:space-y-6">
            <div class="rounded-2xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-white/[0.03]">
                <div class="flex items-center justify-between px-5 py-4 sm:px-6 sm:py-5">
                    <h3 class="text-base font-medium text-gray-800 dark:text-white/90">
                        Buat Partner
                    </h3>
                </div>
                <!-- Alert -->
                <?php if($errors->any()): ?>
                    <?php if (isset($component)) { $__componentOriginal1903f97dee5fcea293eac5373b200b35 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1903f97dee5fcea293eac5373b200b35 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert.alert-1','data' => ['error' => $errors->first()]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('alert.alert-1'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['error' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->first())]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1903f97dee5fcea293eac5373b200b35)): ?>
<?php $attributes = $__attributesOriginal1903f97dee5fcea293eac5373b200b35; ?>
<?php unset($__attributesOriginal1903f97dee5fcea293eac5373b200b35); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1903f97dee5fcea293eac5373b200b35)): ?>
<?php $component = $__componentOriginal1903f97dee5fcea293eac5373b200b35; ?>
<?php unset($__componentOriginal1903f97dee5fcea293eac5373b200b35); ?>
<?php endif; ?>
                <?php elseif(session()->has('success') || session()->has('error')): ?>
                    <?php if (isset($component)) { $__componentOriginal1903f97dee5fcea293eac5373b200b35 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1903f97dee5fcea293eac5373b200b35 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert.alert-1','data' => ['success' => session('success'),'error' => session('error')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('alert.alert-1'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['success' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(session('success')),'error' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(session('error'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1903f97dee5fcea293eac5373b200b35)): ?>
<?php $attributes = $__attributesOriginal1903f97dee5fcea293eac5373b200b35; ?>
<?php unset($__attributesOriginal1903f97dee5fcea293eac5373b200b35); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1903f97dee5fcea293eac5373b200b35)): ?>
<?php $component = $__componentOriginal1903f97dee5fcea293eac5373b200b35; ?>
<?php unset($__componentOriginal1903f97dee5fcea293eac5373b200b35); ?>
<?php endif; ?>
                <?php endif; ?>
                <div class="border-t border-gray-100 dark:border-gray-800">
                    <?php if (isset($component)) { $__componentOriginalcd6ebdf677968b552e90097c98bf4471 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcd6ebdf677968b552e90097c98bf4471 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.partners.form','data' => ['action' => route('partner.store'),'method' => 'post','inputs' => [
                        'name' => ['label' => 'Nama Partner', 'type' => 'text', 'value' => old('name')],
                        'email' => ['label' => 'Email', 'type' => 'email', 'value' => old('email')],
                        'password' => ['label' => 'Password', 'type' => 'text', 'value' => old('password')],
                        'password_confirmation' => [
                            'label' => 'Konfirmasi Password',
                            'type' => 'text',
                            'value' => old('password_confirmation'),
                        ],
                    ],'btnCancel' => ['label' => 'Batal'],'btnSubmit' => ['label' => 'Simpan']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form.partners.form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['action' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('partner.store')),'method' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('post'),'inputs' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([
                        'name' => ['label' => 'Nama Partner', 'type' => 'text', 'value' => old('name')],
                        'email' => ['label' => 'Email', 'type' => 'email', 'value' => old('email')],
                        'password' => ['label' => 'Password', 'type' => 'text', 'value' => old('password')],
                        'password_confirmation' => [
                            'label' => 'Konfirmasi Password',
                            'type' => 'text',
                            'value' => old('password_confirmation'),
                        ],
                    ]),'btn-cancel' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(['label' => 'Batal']),'btn-submit' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(['label' => 'Simpan'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcd6ebdf677968b552e90097c98bf4471)): ?>
<?php $attributes = $__attributesOriginalcd6ebdf677968b552e90097c98bf4471; ?>
<?php unset($__attributesOriginalcd6ebdf677968b552e90097c98bf4471); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcd6ebdf677968b552e90097c98bf4471)): ?>
<?php $component = $__componentOriginalcd6ebdf677968b552e90097c98bf4471; ?>
<?php unset($__componentOriginalcd6ebdf677968b552e90097c98bf4471); ?>
<?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard-app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\PROJECT\management-hotel-dieng\resources\views/partner/create.blade.php ENDPATH**/ ?>