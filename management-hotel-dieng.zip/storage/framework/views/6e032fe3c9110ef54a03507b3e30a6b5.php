

<?php $__env->startSection('content'); ?>
    <div class="p-4 mx-auto max-w-(--breakpoint-2xl) md:p-6">
        <!-- Breadcrumb Start -->
        <?php if (isset($component)) { $__componentOriginal449bf9b97ed15487a2dd22def0878ac7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal449bf9b97ed15487a2dd22def0878ac7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.breadcrumb.type-1','data' => ['breadcrumbs' => [['label' => 'Beranda', 'url' => route('dashboard')], ['label' => 'Produk', 'url' => null]]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('breadcrumb.type-1'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['breadcrumbs' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([['label' => 'Beranda', 'url' => route('dashboard')], ['label' => 'Produk', 'url' => null]])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal449bf9b97ed15487a2dd22def0878ac7)): ?>
<?php $attributes = $__attributesOriginal449bf9b97ed15487a2dd22def0878ac7; ?>
<?php unset($__attributesOriginal449bf9b97ed15487a2dd22def0878ac7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal449bf9b97ed15487a2dd22def0878ac7)): ?>
<?php $component = $__componentOriginal449bf9b97ed15487a2dd22def0878ac7; ?>
<?php unset($__componentOriginal449bf9b97ed15487a2dd22def0878ac7); ?>
<?php endif; ?>
        <!-- Breadcrumb End -->

        <div class="space-y-5 sm:space-y-6">
            <div class="rounded-2xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-white/[0.03]">
                <div class="px-5 py-4 sm:px-6 sm:py-5">
                    <h3 class="text-base font-medium text-gray-800 dark:text-white/90">
                        Produk
                    </h3>
                </div>
                <div class="border-t border-gray-100 dark:border-gray-800">
                    <!-- ====== Table Six Start -->
                    <?php if (isset($component)) { $__componentOriginalcede1545a9f157d042b0f4bc3c9dd8c0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcede1545a9f157d042b0f4bc3c9dd8c0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.tables.table-products','data' => ['headers' => (GetUser()->isPartner() ? ['ID', 'Nama', 'Unit', 'Total Pesanan', 'Aksi'] : ['ID', 'Nama', 'Unit', 'Harga Weekday', 'Harga Weekend', 'Total Pesanan', 'Aksi']),'rows' => $products]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('tables.table-products'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['headers' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute((GetUser()->isPartner() ? ['ID', 'Nama', 'Unit', 'Total Pesanan', 'Aksi'] : ['ID', 'Nama', 'Unit', 'Harga Weekday', 'Harga Weekend', 'Total Pesanan', 'Aksi'])),'rows' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($products)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcede1545a9f157d042b0f4bc3c9dd8c0)): ?>
<?php $attributes = $__attributesOriginalcede1545a9f157d042b0f4bc3c9dd8c0; ?>
<?php unset($__attributesOriginalcede1545a9f157d042b0f4bc3c9dd8c0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcede1545a9f157d042b0f4bc3c9dd8c0)): ?>
<?php $component = $__componentOriginalcede1545a9f157d042b0f4bc3c9dd8c0; ?>
<?php unset($__componentOriginalcede1545a9f157d042b0f4bc3c9dd8c0); ?>
<?php endif; ?>
                    <!-- ====== Table Six End -->
                </div>
            </div>
        </div>
    </div>

    <?php if (isset($component)) { $__componentOriginalbdc31d7c11973739af12d66580af931c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbdc31d7c11973739af12d66580af931c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.js.flowbite-datatable','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('js.flowbite-datatable'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbdc31d7c11973739af12d66580af931c)): ?>
<?php $attributes = $__attributesOriginalbdc31d7c11973739af12d66580af931c; ?>
<?php unset($__attributesOriginalbdc31d7c11973739af12d66580af931c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbdc31d7c11973739af12d66580af931c)): ?>
<?php $component = $__componentOriginalbdc31d7c11973739af12d66580af931c; ?>
<?php unset($__componentOriginalbdc31d7c11973739af12d66580af931c); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard-app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\PROJECT\management-hotel-dieng\resources\views/calendar/index.blade.php ENDPATH**/ ?>