

<?php $__env->startSection('content'); ?>
    <div class="p-4 mx-auto max-w-(--breakpoint-2xl) md:p-6">
        <!-- Breadcrumb Start -->
        <?php if (isset($component)) { $__componentOriginal449bf9b97ed15487a2dd22def0878ac7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal449bf9b97ed15487a2dd22def0878ac7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.breadcrumb.type-1','data' => ['breadcrumbs' => [
            ['label' => 'Beranda', 'url' => route('dashboard')],
            ['label' => 'Reservation', 'url' => route('reservation.index')],
            ['label' => 'Detail Reservation', 'url' => null],
        ]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('breadcrumb.type-1'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['breadcrumbs' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([
            ['label' => 'Beranda', 'url' => route('dashboard')],
            ['label' => 'Reservation', 'url' => route('reservation.index')],
            ['label' => 'Detail Reservation', 'url' => null],
        ])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal449bf9b97ed15487a2dd22def0878ac7)): ?>
<?php $attributes = $__attributesOriginal449bf9b97ed15487a2dd22def0878ac7; ?>
<?php unset($__attributesOriginal449bf9b97ed15487a2dd22def0878ac7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal449bf9b97ed15487a2dd22def0878ac7)): ?>
<?php $component = $__componentOriginal449bf9b97ed15487a2dd22def0878ac7; ?>
<?php unset($__componentOriginal449bf9b97ed15487a2dd22def0878ac7); ?>
<?php endif; ?>
        <!-- Breadcrumb End -->

        <div class="space-y-5 sm:space-y-6">
            <div class="rounded-2xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-white/[0.03]">
                <div class="flex items-center justify-between px-5 py-4 sm:px-6 sm:py-5">
                    <h3 class="text-base font-medium text-gray-800 dark:text-white/90">
                        Detail Pemesanan List
                    </h3>
                    <button
                        onclick="showConfirmationSwal('Menyetujui Semua Pemesanan ?', 'Anda yakin ingin menyetujui semua pemesanan ini ?', 'warning', () => approveAllReservation('<?php echo e($reservation_details[0]['transaksi_id']); ?>'))"
                        class="flex items-center gap-1 ms-auto rounded-full px-3 py-1.5 border border-blue-500 bg-blue-500 dark:bg-blue-700 text-theme-sm font-medium text-white hover:bg-blue-600 dark:hover:bg-blue-800 transition duration-300 shadow-sm">
                        <span>Approve All</span>
                    </button>
                </div>
                <div class="border-t border-gray-100 dark:border-gray-800">
                    <!-- ====== Table Six Start -->
                    <?php if (isset($component)) { $__componentOriginala7c243fe49e8cb48021d62ceeac9acf1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala7c243fe49e8cb48021d62ceeac9acf1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.tables.table-detail-reservation','data' => ['rows' => $reservation_details]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('tables.table-detail-reservation'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['rows' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($reservation_details)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala7c243fe49e8cb48021d62ceeac9acf1)): ?>
<?php $attributes = $__attributesOriginala7c243fe49e8cb48021d62ceeac9acf1; ?>
<?php unset($__attributesOriginala7c243fe49e8cb48021d62ceeac9acf1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala7c243fe49e8cb48021d62ceeac9acf1)): ?>
<?php $component = $__componentOriginala7c243fe49e8cb48021d62ceeac9acf1; ?>
<?php unset($__componentOriginala7c243fe49e8cb48021d62ceeac9acf1); ?>
<?php endif; ?>
                    <!-- ====== Table Six End -->
                </div>
            </div>
        </div>
    </div>

    <?php if (isset($component)) { $__componentOriginalbdc31d7c11973739af12d66580af931c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbdc31d7c11973739af12d66580af931c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.js.flowbite-datatable','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('js.flowbite-datatable'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbdc31d7c11973739af12d66580af931c)): ?>
<?php $attributes = $__attributesOriginalbdc31d7c11973739af12d66580af931c; ?>
<?php unset($__attributesOriginalbdc31d7c11973739af12d66580af931c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbdc31d7c11973739af12d66580af931c)): ?>
<?php $component = $__componentOriginalbdc31d7c11973739af12d66580af931c; ?>
<?php unset($__componentOriginalbdc31d7c11973739af12d66580af931c); ?>
<?php endif; ?>

    <script>
        function approveAllReservation(transaksi_id) {
            fetch(`https://villahoteldieng.com/api/v1/reservations/${transaksi_id}/acceptAll`, {
                    method: 'POST',
                    headers: {
                        'Authorization': 'Bearer <?php echo e(env('SANCTUM_TOKEN_PREFIX', '')); ?>', // Ganti {API_KEY} dengan kunci API Anda
                        'Content-Type': 'application/json'
                    }
                })
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Network response was not ok ' + response.statusText);
                    }
                    return response.json();
                })
                .then(data => {
                    showSuccessSwal('Berhasil', data.message);
                    console.log('Success:', data.message);
                })
                .catch(error => {
                    showSuccessSwal('Gagal', error);
                    console.error('Error:', error);
                });
        }

        function approveReservation(id) {
            fetch(`https://villahoteldieng.com/api/v1/reservations/${id}/accept`, {
                    method: 'POST',
                    headers: {
                        'Authorization': 'Bearer <?php echo e(env('SANCTUM_TOKEN_PREFIX', '')); ?>', // Ganti {API_KEY} dengan kunci API Anda
                        'Content-Type': 'application/json'
                    }
                })
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Network response was not ok ' + response.statusText);
                    }
                    return response.json();
                })
                .then(data => {
                    showSuccessSwal('Berhasil', data.message);
                    console.log('Success:', data.message);
                })
                .catch(error => {
                    showSuccessSwal('Gagal', error);
                    console.error('Error:', error);
                });
        }

        function rejectReservation(id) {
            fetch(`https://villahoteldieng.com/api/v1/reservations/${id}/reject`, {
                    method: 'POST',
                    headers: {
                        'Authorization': 'Bearer <?php echo e(env('SANCTUM_TOKEN_PREFIX', '')); ?>', // Ganti {API_KEY} dengan kunci API Anda
                        'Content-Type': 'application/json'
                    }
                })
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Network response was not ok ' + response.statusText);
                    }
                    return response.json();
                })
                .then(data => {
                    showSuccessSwal('Berhasil', data.message);
                    console.log('Success:', data.message);
                })
                .catch(error => {
                    showSuccessSwal('Gagal', error.message);
                    console.error('Error:', error.message);
                });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard-app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\PROJECT\management-hotel-dieng\resources\views/reservation/show.blade.php ENDPATH**/ ?>