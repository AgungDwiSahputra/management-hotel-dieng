<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'action' => route('partner.store'),
    'method' => 'post',
    'inputs' => [
        'name' => ['label' => 'Nama Partner', 'type' => 'text', 'value' => old('name')],
        'email' => ['label' => 'Email', 'type' => 'email', 'value' => old('email')],
        'password' => ['label' => 'Password', 'type' => 'text', 'value' => old('password')],
        'password_confirmation' => [
            'label' => 'Konfirmasi Password',
            'type' => 'text',
            'value' => old('password_confirmation'),
        ],
    ],
    'btnCancel' => [
        'label' => 'Batal',
    ],
    'btnSubmit' => [
        'label' => 'Simpan',
    ]
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'action' => route('partner.store'),
    'method' => 'post',
    'inputs' => [
        'name' => ['label' => 'Nama Partner', 'type' => 'text', 'value' => old('name')],
        'email' => ['label' => 'Email', 'type' => 'email', 'value' => old('email')],
        'password' => ['label' => 'Password', 'type' => 'text', 'value' => old('password')],
        'password_confirmation' => [
            'label' => 'Konfirmasi Password',
            'type' => 'text',
            'value' => old('password_confirmation'),
        ],
    ],
    'btnCancel' => [
        'label' => 'Batal',
    ],
    'btnSubmit' => [
        'label' => 'Simpan',
    ]
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<form class="px-5 py-4 sm:px-6 sm:py-5" action="<?php echo e($action); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php if($method === 'put'): ?>
        <?php echo method_field('PUT'); ?>
    <?php elseif($method === 'patch'): ?>
        <?php echo method_field('PATCH'); ?>
    <?php elseif($method === 'delete'): ?>
        <?php echo method_field('DELETE'); ?>
    <?php else: ?>
        <?php echo method_field('POST'); ?>
    <?php endif; ?>

    <div class="grid grid-cols-1 sm:grid-cols-2 gap-5">
        <?php $__currentLoopData = $inputs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name => $input): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div>
                <?php if($input['type'] === 'text'): ?>
                    <?php if (isset($component)) { $__componentOriginalf174c68dfd4cda2352071cb87561ecc2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf174c68dfd4cda2352071cb87561ecc2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.input-text','data' => ['name' => ''.e($name).'','label' => ''.e($input['label']).'','value' => ''.e($input['value']).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form.input-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => ''.e($name).'','label' => ''.e($input['label']).'','value' => ''.e($input['value']).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf174c68dfd4cda2352071cb87561ecc2)): ?>
<?php $attributes = $__attributesOriginalf174c68dfd4cda2352071cb87561ecc2; ?>
<?php unset($__attributesOriginalf174c68dfd4cda2352071cb87561ecc2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf174c68dfd4cda2352071cb87561ecc2)): ?>
<?php $component = $__componentOriginalf174c68dfd4cda2352071cb87561ecc2; ?>
<?php unset($__componentOriginalf174c68dfd4cda2352071cb87561ecc2); ?>
<?php endif; ?>
                <?php elseif($input['type'] === 'email'): ?>
                    <?php if (isset($component)) { $__componentOriginal249fa9101ed26337a42f429aa669bd79 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal249fa9101ed26337a42f429aa669bd79 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.input-email','data' => ['name' => ''.e($name).'','label' => ''.e($input['label']).'','value' => ''.e($input['value']).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form.input-email'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => ''.e($name).'','label' => ''.e($input['label']).'','value' => ''.e($input['value']).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal249fa9101ed26337a42f429aa669bd79)): ?>
<?php $attributes = $__attributesOriginal249fa9101ed26337a42f429aa669bd79; ?>
<?php unset($__attributesOriginal249fa9101ed26337a42f429aa669bd79); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal249fa9101ed26337a42f429aa669bd79)): ?>
<?php $component = $__componentOriginal249fa9101ed26337a42f429aa669bd79; ?>
<?php unset($__componentOriginal249fa9101ed26337a42f429aa669bd79); ?>
<?php endif; ?>
                <?php elseif($input['type'] === 'number'): ?>
                    <?php if (isset($component)) { $__componentOriginal14c457ad1d46b718d081f1708631451c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal14c457ad1d46b718d081f1708631451c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.input-number','data' => ['name' => ''.e($name).'','label' => ''.e($input['label']).'','value' => ''.e($input['value']).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form.input-number'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => ''.e($name).'','label' => ''.e($input['label']).'','value' => ''.e($input['value']).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal14c457ad1d46b718d081f1708631451c)): ?>
<?php $attributes = $__attributesOriginal14c457ad1d46b718d081f1708631451c; ?>
<?php unset($__attributesOriginal14c457ad1d46b718d081f1708631451c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal14c457ad1d46b718d081f1708631451c)): ?>
<?php $component = $__componentOriginal14c457ad1d46b718d081f1708631451c; ?>
<?php unset($__componentOriginal14c457ad1d46b718d081f1708631451c); ?>
<?php endif; ?>
                <?php endif; ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="flex items-center justify-end gap-1 mt-5">
        <button type="button" onclick="window.location.href = '<?php echo e(route('partner.index')); ?>'"
            class="text-white bg-gradient-to-r from-red-400 via-red-500 to-red-600 hover:bg-gradient-to-br focus:ring-4 focus:outline-none focus:ring-red-300 dark:focus:ring-red-800 font-medium rounded-lg text-sm px-5 py-2.5 text-center me-2 mb-2"><?php echo e($btnCancel['label']); ?></button>
        <button type="submit"
            class="text-white bg-gradient-to-r from-blue-500 via-blue-600 to-blue-700 hover:bg-gradient-to-br focus:ring-4 focus:outline-none focus:ring-blue-300 dark:focus:ring-blue-800 font-medium rounded-lg text-sm px-5 py-2.5 text-center me-2 mb-2"><?php echo e($btnSubmit['label']); ?></button>
    </div>
</form>
<?php /**PATH D:\PROJECT\management-hotel-dieng\resources\views/components/form/partners/form.blade.php ENDPATH**/ ?>