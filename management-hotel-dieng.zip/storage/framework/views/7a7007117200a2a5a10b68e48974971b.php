<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'type' => 'show',
    'key' => '0',
    'textButton' => 'Ubah Data',
    'data' => [
        'title' => 'Create New Pemesanan',
        'form' => [
            [
                'type' => 'text',
                'name' => 'name',
                'label' => 'Nama Produk',
                'value' => 'Agung Dwi Sahputra',
            ],
            [
                'type' => 'number',
                'name' => 'price',
                'label' => 'Harga',
            ],
            [
                'type' => 'select',
                'name' => 'category',
                'label' => 'Kategori',
                'options' => [
                    ['value' => '', 'label' => 'Pilih Kategori'],
                    ['value' => 'Villa', 'label' => 'Villa'],
                    ['value' => 'Hotel', 'label' => 'Hotel'],
                    ['value' => 'Cottage', 'label' => 'Cottage'],
                ],
            ],
            [
                'type' => 'textarea',
                'name' => 'description',
                'label' => 'Deskripsi',
            ],
        ],
        'action' => '#',
    ],
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'type' => 'show',
    'key' => '0',
    'textButton' => 'Ubah Data',
    'data' => [
        'title' => 'Create New Pemesanan',
        'form' => [
            [
                'type' => 'text',
                'name' => 'name',
                'label' => 'Nama Produk',
                'value' => 'Agung Dwi Sahputra',
            ],
            [
                'type' => 'number',
                'name' => 'price',
                'label' => 'Harga',
            ],
            [
                'type' => 'select',
                'name' => 'category',
                'label' => 'Kategori',
                'options' => [
                    ['value' => '', 'label' => 'Pilih Kategori'],
                    ['value' => 'Villa', 'label' => 'Villa'],
                    ['value' => 'Hotel', 'label' => 'Hotel'],
                    ['value' => 'Cottage', 'label' => 'Cottage'],
                ],
            ],
            [
                'type' => 'textarea',
                'name' => 'description',
                'label' => 'Deskripsi',
            ],
        ],
        'action' => '#',
    ],
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<div id="<?php echo e($type); ?>-modal-<?php echo e($key); ?>" data-modal-backdrop="static" tabindex="-1" aria-hidden="true"
    class="hidden overflow-y-auto overflow-x-hidden fixed top-0 right-0 left-0 z-50 justify-center items-center w-full md:inset-0 h-[calc(100%-1rem)] max-h-full">
    <div class="relative p-4 w-full max-w-md max-h-full">
        <!-- Modal content -->
        <div class="relative bg-white rounded-lg shadow-sm dark:bg-gray-700">
            <!-- Modal header -->
            <div
                class="flex items-center justify-between p-4 md:p-5 border-b rounded-t dark:border-gray-600 border-gray-200">
                <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                    <?php echo e($data['title']); ?>

                </h3>
                <button type="button"
                    class="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm w-8 h-8 ms-auto inline-flex justify-center items-center dark:hover:bg-gray-600 dark:hover:text-white"
                    data-modal-toggle="<?php echo e($type); ?>-modal-<?php echo e($key); ?>">
                    <svg class="w-3 h-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none"
                        viewBox="0 0 14 14">
                        <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6" />
                    </svg>
                    <span class="sr-only">Close modal</span>
                </button>
            </div>
            <!-- Modal body -->
            <form action="<?php echo e($data['action']); ?>" method="POST" class="p-4 md:p-5">
                <?php echo csrf_field(); ?>
                <div class="grid gap-4 mb-4 grid-cols-2">
                    <?php $__currentLoopData = $data['form']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-span-2">
                            <label for="<?php echo e($field['name']); ?>" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
                                <?php echo e($field['label']); ?>

                            </label>
                            <?php if($field['type'] === 'text' || $field['type'] === 'number'): ?>
                                <input
                                    type="<?php echo e($field['type']); ?>"
                                    name="<?php echo e($field['name']); ?>"
                                    id="<?php echo e($field['name']); ?>"
                                    class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-600 dark:border-gray-500 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
                                    placeholder="Masukkan <?php echo e(strtolower($field['label'])); ?>"
                                    value="<?php echo e(old($field['name'], $field['value'] ?? '')); ?>"
                                    <?php if($type == 'show'): ?> readonly <?php endif; ?>
                                    required
                                >
                            <?php elseif($field['type'] === 'select'): ?>
                                <select
                                    name="<?php echo e($field['name']); ?>"
                                    id="<?php echo e($field['name']); ?>"
                                    class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-600 dark:border-gray-500 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
                                    <?php if($type == 'show'): ?> disabled <?php endif; ?>
                                    required
                                >
                                    <?php $__currentLoopData = $field['options']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($option['value']); ?>" <?php if(isset($field['value']) && $field['value'] == $option['value']): ?> selected <?php endif; ?>>
                                            <?php echo e($option['label']); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            <?php elseif($field['type'] === 'textarea'): ?>
                                <textarea
                                    name="<?php echo e($field['name']); ?>"
                                    id="<?php echo e($field['name']); ?>"
                                    rows="3"
                                    class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-600 dark:border-gray-500 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
                                    placeholder="Masukkan <?php echo e(strtolower($field['label'])); ?>"
                                    <?php if($type == 'show'): ?> readonly <?php endif; ?>
                                    required
                                ><?php echo e(old($field['name'], $field['value'] ?? '')); ?></textarea>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <?php if($type != 'show'): ?>
                    <button type="submit"
                        class="text-white inline-flex items-center bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">
                        
                        <?php echo e($textButton); ?>

                    </button>
                <?php endif; ?>
            </form>
        </div>
    </div>
</div>
<?php /**PATH D:\PROJECT\management-hotel-dieng\resources\views/components/modals/modal-form.blade.php ENDPATH**/ ?>