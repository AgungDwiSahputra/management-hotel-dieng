<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'headers' => ['ID', 'Nama Produk', 'Kamar', 'Max. Orang', 'Harga Weekday', 'Harga Weekend', 'Dibuat', 'Action'],
    'rows' => [
        [
            'id' => 'd03d9b8e-6a20-407e-8a24-4c5d266466b7',
            'category_id' => 'cd12155b-fca6-4418-8515-a2e9dacc97e3',
            'owner' => 'admin@app.com',
            'name' => '1 Kamar Best View Lantai 3',
            'slug' => '1-kamar-best-view-lantai-3',
            'unit' => 1,
            'total_reservations' => 0,
            'kamar' => 1,
            'orang' => 4,
            'maks_orang' => 6,
            'lokasi' => '1 Kamar Best View Lantai 3',
            'harga_weekday' => 500000,
            'harga_weekend' => 600000,
            'label' => null,
            'urutan' => 5,
            'status' => 'draft',
            'created_at' => '2025-07-01T23:58:02.000000Z',
            'updated_at' => '2025-07-01T23:58:12.000000Z',
        ],
    ],
    'btnAction' => [
        [
            'label' => 'Ketersediaan',
            'route' => 'calendar.show',
            'method' => null,
        ],
    ],
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'headers' => ['ID', 'Nama Produk', 'Kamar', 'Max. Orang', 'Harga Weekday', 'Harga Weekend', 'Dibuat', 'Action'],
    'rows' => [
        [
            'id' => 'd03d9b8e-6a20-407e-8a24-4c5d266466b7',
            'category_id' => 'cd12155b-fca6-4418-8515-a2e9dacc97e3',
            'owner' => 'admin@app.com',
            'name' => '1 Kamar Best View Lantai 3',
            'slug' => '1-kamar-best-view-lantai-3',
            'unit' => 1,
            'total_reservations' => 0,
            'kamar' => 1,
            'orang' => 4,
            'maks_orang' => 6,
            'lokasi' => '1 Kamar Best View Lantai 3',
            'harga_weekday' => 500000,
            'harga_weekend' => 600000,
            'label' => null,
            'urutan' => 5,
            'status' => 'draft',
            'created_at' => '2025-07-01T23:58:02.000000Z',
            'updated_at' => '2025-07-01T23:58:12.000000Z',
        ],
    ],
    'btnAction' => [
        [
            'label' => 'Ketersediaan',
            'route' => 'calendar.show',
            'method' => null,
        ],
    ],
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<div class="overflow-hidden rounded-xl p-5 sm:p-6 bg-white dark:bg-gray-900 dark:border-gray-800">
    <div class="max-w-full overflow-x-auto">
        <table id="default-table" class="datatable min-w-full bg-white dark:bg-gray-900">
            <!-- table header start -->
            <thead class="bg-gray-50 dark:bg-gray-800">
                <tr class="border-b border-gray-100 dark:border-gray-800">
                    <?php $__currentLoopData = $headers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $header): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th class="px-5 py-3 sm:px-6">
                            <div class="flex items-center">
                                <p class="font-medium text-gray-500 text-theme-xs dark:text-gray-400">
                                    <?php echo e($header); ?>

                                </p>
                            </div>
                        </th>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
            </thead>
            <!-- table header end -->
            <!-- table body start -->
            <tbody class="divide-y divide-gray-100 dark:divide-gray-800">
                <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="bg-white dark:bg-gray-900 hover:bg-gray-50 dark:hover:bg-gray-800">
                        <?php if(isset($row['id'])): ?>
                            <td class="px-5 py-4 sm:px-6">
                                <span class="text-gray-500 text-theme-xs font-bold">
                                    <?php echo e(strtoupper(substr($row['id'], 0, 2))); ?>

                                </span>
                            </td>
                        <?php endif; ?>
                        <?php if(isset($row['name'])): ?>
                            <td class="px-5 py-4 sm:px-6">
                                <span class="block font-medium text-gray-800 text-theme-sm dark:text-white/90">
                                    <?php echo e($row['name']); ?>

                                </span>
                            </td>
                        <?php endif; ?>
                        <?php if(isset($row['slug'])): ?>
                            <td class="px-5 py-4 sm:px-6">
                                <span class="text-gray-700 dark:text-gray-300 font-semibold"><?php echo e($row['slug']); ?></span>
                            </td>
                        <?php endif; ?>
                        <?php if(isset($row['unit'])): ?>
                            <td class="px-5 py-4 sm:px-6">
                                <span class="text-gray-700 dark:text-gray-300 font-semibold"><?php echo e($row['unit']); ?></span>
                            </td>
                        <?php endif; ?>
                        <?php if(isset($row['kamar'])): ?>
                            <td class="px-5 py-4 sm:px-6">
                                <span class="text-gray-700 dark:text-gray-300 font-semibold"><?php echo e($row['kamar']); ?></span>
                            </td>
                        <?php endif; ?>
                        <?php if(isset($row['maks_orang'])): ?>
                            <td class="px-5 py-4 sm:px-6">
                                <span class="text-gray-500 text-theme-sm dark:text-gray-400"><?php echo e($row['maks_orang']); ?></span>
                            </td>
                        <?php endif; ?>
                        <?php if(isset($row['harga_weekday'])): ?>
                            <td class="px-5 py-4 sm:px-6">
                                <span
                                    class="text-gray-500 text-theme-sm dark:text-gray-400">Rp<?php echo e(number_format($row['harga_weekday'], 0, ',', '.')); ?></span>
                            </td>
                        <?php endif; ?>
                        <?php if(isset($row['harga_weekend'])): ?>
                            <td class="px-5 py-4 sm:px-6">
                                <span
                                    class="text-gray-500 text-theme-sm dark:text-gray-400">Rp<?php echo e(number_format($row['harga_weekend'], 0, ',', '.')); ?></span>
                            </td>
                        <?php endif; ?>
                        <?php if(isset($row['total_reservations'])): ?>
                            <td class="px-5 py-4 sm:px-6">
                                <span class="text-gray-700 dark:text-gray-300 font-semibold"><?php echo e($row['total_reservations']); ?></span>
                            </td>
                        <?php endif; ?>
                        <?php if(isset($row['created_at'])): ?>
                            <td class="px-5 py-4 sm:px-6">
                                <span class="text-gray-500 text-theme-sm dark:text-gray-400">
                                    <?php echo e(\Carbon\Carbon::parse($row['created_at'])->format('d M Y')); ?>

                                </span>
                            </td>
                        <?php endif; ?>
                        <td class="px-5 py-4 sm:px-6">
                            <div class="flex items-center gap-1">
                                <?php $__currentLoopData = $btnAction; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $btn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($btn['method'] == 'delete'): ?>
                                        <form action="<?php echo e(route($btn['route'], $row['id'])); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit"
                                                class="flex items-center gap-1 rounded-full px-3 py-1.5 border border-red-500 bg-red-500 dark:bg-red-900 text-theme-sm font-medium text-white dark:text-white hover:bg-red-600 dark:hover:bg-red-800 transition duration-300">
                                                <span><?php echo e($btn['label']); ?></span>
                                            </button>
                                        </form>
                                    <?php else: ?>
                                        <a href="<?php echo e(route($btn['route'], $row['id'])); ?>"
                                            class="flex items-center gap-1 rounded-full px-3 py-1.5 border border-gray-300 bg-blue-500 dark:bg-blue-900 text-theme-sm font-medium text-white dark:text-white hover:bg-blue-600 dark:hover:bg-blue-800 transition duration-300">
                                            <span><?php echo e($btn['label']); ?></span>
                                        </a>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php /**PATH D:\PROJECT\management-hotel-dieng\resources\views/components/tables/table-products.blade.php ENDPATH**/ ?>